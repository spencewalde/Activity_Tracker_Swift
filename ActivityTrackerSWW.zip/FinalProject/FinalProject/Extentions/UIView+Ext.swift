//
//  UIView+Ext.swift
//  FinalProject
//
//  Created by Williams-Waldemar, Spencer A on 11/27/20.
//  Copyright © 2020 Williams-Waldemar, Spencer A. All rights reserved.
//

import UIKit

extension UIView {

    func pin(to superView: UIView){
        translatesAutoresizingMaskIntoConstraints   = false
        topAnchor.constraint(equalTo: superView.topAnchor).isActive = true
        leadingAnchor.constraint(equalTo: superView.leadingAnchor).isActive = true
        trailingAnchor.constraint(equalTo: superView.trailingAnchor).isActive = true
        bottomAnchor.constraint(equalTo: superView.bottomAnchor,constant: -128).isActive = true
        heightAnchor.constraint(equalToConstant: -128).isActive = true

    }
    
    public func removeAllConstraints(){
        var _superView = self.superview
        
        while let superview = _superView{
            for constraint in superview.constraints{
                if let first = constraint.firstItem as? UIView, first == self {
                    superview.removeConstraint(constraint)
                }
                if let second = constraint.firstItem as? UIView, second == self{
                    superview.removeConstraint(constraint)
                }
            }
            _superView = superview.superview
        }
        self.removeConstraints(self.constraints)
        self.translatesAutoresizingMaskIntoConstraints = true
    }

}


